```markdown
# SkillShare MVP – Fullstack Starter

This repo contains a minimal skeleton for a daily skill rental app with both a Django REST backend and a Flutter frontend.

---

## Backend

- Location: `backend/`
- Stack: Django + DRF + JWT + CORS

Quick start:
```bash
cd backend
python -m venv venv
. venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

API base: `http://localhost:8000/api/`

---

## Frontend

- Location: `frontend/`
- Stack: Flutter (`http`, `geolocator`)

Quick start:
```bash
cd frontend
flutter pub get
flutter run
```
If using Android emulator, API base is already set to `10.0.2.2`. Adjust in `lib/main.dart` if running on a device.

---

## Notes

- Add authentication (JWT) and booking/payment flows as needed.
- Extend models/serializers for more features.
- For production: set proper secrets and environment variables, don't use DEBUG=True.
```