from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()

class Service(models.Model):
    provider = models.ForeignKey(User, on_delete=models.CASCADE, related_name='services')
    title = models.CharField(max_length=120)
    description = models.TextField(blank=True)
    price_cents = models.IntegerField(default=0)
    duration_minutes = models.IntegerField(default=60)
    latitude = models.FloatField(null=True, blank=True)
    longitude = models.FloatField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def price_display(self):
        return f"{self.price_cents/100:.2f}"

    def __str__(self):
        return f"{self.title} by {self.provider.username}"

class Booking(models.Model):
    service = models.ForeignKey(Service, on_delete=models.CASCADE, related_name='bookings')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='bookings')
    scheduled_for = models.DateTimeField()
    created_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, default='pending')

    def __str__(self):
        return f"Booking {self.id} - {self.service.title}"