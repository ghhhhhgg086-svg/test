from rest_framework import serializers
from .models import Service, Booking
from django.contrib.auth import get_user_model

User = get_user_model()

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id','username','first_name','last_name']

class ServiceSerializer(serializers.ModelSerializer):
    provider = UserSerializer(read_only=True)
    distance = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = Service
        fields = ['id','provider','title','description','price_cents','duration_minutes','latitude','longitude','created_at','distance']

    def get_distance(self, obj):
        return None

class BookingSerializer(serializers.ModelSerializer):
    service = ServiceSerializer(read_only=True)
    service_id = serializers.PrimaryKeyRelatedField(queryset=Service.objects.all(), source='service', write_only=True)

    class Meta:
        model = Booking
        fields = ['id','service','service_id','user','scheduled_for','created_at','status']
        read_only_fields = ['user','created_at','status']

    def create(self, validated_data):
        request = self.context.get('request')
        user = request.user
        booking = Booking.objects.create(user=user, **validated_data)
        return booking