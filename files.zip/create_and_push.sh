#!/usr/bin/env bash
set -e

REPO_URL="https://github.com/ghhhhhgg086-svg/test.git"
BRANCH="main"

# Create directories
mkdir -p backend/backend backend/api frontend/lib

# Write files
cat > .gitignore <<'EOF'
# Python
backend/db.sqlite3
backend/__pycache__/
backend/api/__pycache__/
backend/backend/__pycache__/
*.pyc
*.pyo
*.pyd
.Python

# Django
*.log
*.pot
*.pyc
__pycache__/
local_settings.py
db.sqlite3
media

# Flutter
frontend/build/
frontend/.dart_tool/
frontend/.packages
frontend/.flutter-plugins
frontend/.flutter-plugins-dependencies
frontend/.idea/
frontend/.vscode/
frontend/.DS_Store
frontend/.metadata
EOF

cat > backend/requirements.txt <<'EOF'
Django>=4.2
djangorestframework
djangorestframework-simplejwt
psycopg2-binary
django-cors-headers
EOF

cat > backend/manage.py <<'EOF'
#!/usr/bin/env python
import os
import sys

def main():
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'backend.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError("Couldn't import Django.") from exc
    execute_from_command_line(sys.argv)

if __name__ == '__main__':
    main()
EOF
chmod +x backend/manage.py

cat > backend/backend/settings.py <<'EOF'
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
SECRET_KEY = 'change-me'
DEBUG = True
ALLOWED_HOSTS = ['*']

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'rest_framework',
    'corsheaders',
    'api',
]

MIDDLEWARE = [
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
]

ROOT_URLCONF = 'backend.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'backend.wsgi.application'

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

AUTH_PASSWORD_VALIDATORS = []

LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'UTC'
USE_I18N = True
USE_TZ = True

STATIC_URL = 'static/'

REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'rest_framework_simplejwt.authentication.JWTAuthentication',
    ),
}

CORS_ALLOW_ALL_ORIGINS = True
EOF

cat > backend/backend/urls.py <<'EOF'
from django.contrib import admin
from django.urls import path, include
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/auth/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/auth/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('api/', include('api.urls')),
]
EOF

cat > backend/backend/wsgi.py <<'EOF'
import os
from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'backend.settings')
application = get_wsgi_application()
EOF

cat > backend/api/models.py <<'EOF'
from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()

class Service(models.Model):
    provider = models.ForeignKey(User, on_delete=models.CASCADE, related_name='services')
    title = models.CharField(max_length=120)
    description = models.TextField(blank=True)
    price_cents = models.IntegerField(default=0)
    duration_minutes = models.IntegerField(default=60)
    latitude = models.FloatField(null=True, blank=True)
    longitude = models.FloatField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def price_display(self):
        return f"{self.price_cents/100:.2f}"

    def __str__(self):
        return f"{self.title} by {self.provider.username}"

class Booking(models.Model):
    service = models.ForeignKey(Service, on_delete=models.CASCADE, related_name='bookings')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='bookings')
    scheduled_for = models.DateTimeField()
    created_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, default='pending')

    def __str__(self):
        return f"Booking {self.id} - {self.service.title}"
EOF

cat > backend/api/serializers.py <<'EOF'
from rest_framework import serializers
from .models import Service, Booking
from django.contrib.auth import get_user_model

User = get_user_model()

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id','username','first_name','last_name']

class ServiceSerializer(serializers.ModelSerializer):
    provider = UserSerializer(read_only=True)
    distance = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = Service
        fields = ['id','provider','title','description','price_cents','duration_minutes','latitude','longitude','created_at','distance']

    def get_distance(self, obj):
        return None

class BookingSerializer(serializers.ModelSerializer):
    service = ServiceSerializer(read_only=True)
    service_id = serializers.PrimaryKeyRelatedField(queryset=Service.objects.all(), source='service', write_only=True)

    class Meta:
        model = Booking
        fields = ['id','service','service_id','user','scheduled_for','created_at','status']
        read_only_fields = ['user','created_at','status']

    def create(self, validated_data):
        request = self.context.get('request')
        user = request.user
        booking = Booking.objects.create(user=user, **validated_data)
        return booking
EOF

cat > backend/api/views.py <<'EOF'
from rest_framework import viewsets, permissions
from .models import Service, Booking
from .serializers import ServiceSerializer, BookingSerializer

class IsOwnerOrReadOnly(permissions.BasePermission):
    def has_object_permission(self, request, view, obj):
        if request.method in permissions.SAFE_METHODS:
            return True
        return obj.provider == request.user

class ServiceViewSet(viewsets.ModelViewSet):
    queryset = Service.objects.all().order_by('-created_at')
    serializer_class = ServiceSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly, IsOwnerOrReadOnly]

    def perform_create(self, serializer):
        serializer.save(provider=self.request.user)

class BookingViewSet(viewsets.ModelViewSet):
    queryset = Booking.objects.all().order_by('-created_at')
    serializer_class = BookingSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        return Booking.objects.filter(user=user)
EOF

cat > backend/api/urls.py <<'EOF'
from rest_framework.routers import DefaultRouter
from .views import ServiceViewSet, BookingViewSet

router = DefaultRouter()
router.register(r'services', ServiceViewSet)
router.register(r'bookings', BookingViewSet)

urlpatterns = router.urls
EOF

cat > backend/api/__init__.py <<'EOF'
# empty
EOF

cat > backend/__init__.py <<'EOF'
# empty
EOF

cat > frontend/pubspec.yaml <<'EOF'
name: skillshare_mvp
description: SkillShare MVP
publish_to: 'none'
version: 0.0.1

environment:
  sdk: '>=2.18.0 <3.0.0'

dependencies:
  flutter:
    sdk: flutter
  cupertino_icons: ^1.0.2
  http: ^0.13.5
  flutter_secure_storage: ^8.0.0
  geolocator: ^9.0.2
EOF

mkdir -p frontend/lib
cat > frontend/lib/main.dart <<'EOF'
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const API_BASE = 'http://10.0.2.2:8000/api'; // use 10.0.2.2 for Android emulator

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SkillShare MVP',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List services = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    fetchServices();
  }

  Future fetchServices() async {
    try {
      final res = await http.get(Uri.parse('$API_BASE/services/'));
      if (res.statusCode == 200) {
        setState(() {
          services = json.decode(res.body);
          loading = false;
        });
      } else {
        setState(() => loading = false);
      }
    } catch (e) {
      setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('SkillShare')),
      body: loading
          ? Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: services.length,
              itemBuilder: (ctx, i) {
                final s = services[i];
                return ListTile(
                  title: Text(s['title'] ?? 'No title'),
                  subtitle: Text('${(s['price_cents'] ?? 0)/100} TND'),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => ServiceDetail(service: s)),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {},
        child: Icon(Icons.add),
        tooltip: 'Add service (provider)',
      ),
    );
  }
}

class ServiceDetail extends StatelessWidget {
  final Map service;
  ServiceDetail({required this.service});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(service['title'] ?? 'Service')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(service['description'] ?? ''),
            SizedBox(height: 20),
            Text('Price: ${(service['price_cents'] ?? 0)/100} TND'),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Booking not implemented yet')));
              },
              child: Text('Book Now'),
            )
          ],
        ),
      ),
    );
  }
}
EOF

cat > frontend/.gitignore <<'EOF'
build/
.dart_tool/
.packages
.flutter-plugins
.flutter-plugins-dependencies
.idea/
.vscode/
.DS_Store
.metadata
EOF

cat > README.md <<'EOF'
# SkillShare MVP – Fullstack Starter

This repo contains a minimal skeleton for a daily skill rental app with both a Django REST backend and a Flutter frontend.

---

## Backend

- Location: `backend/`
- Stack: Django + DRF + JWT + CORS

Quick start:
\`\`\`bash
cd backend
python -m venv venv
. venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
\`\`\`

API base: `http://localhost:8000/api/`

---

## Frontend

- Location: `frontend/`
- Stack: Flutter (\`http\`, \`geolocator\`)

Quick start:
\`\`\`bash
cd frontend
flutter pub get
flutter run
\`\`\`
If using Android emulator, API base is already set to \`10.0.2.2\`. Adjust in \`lib/main.dart\` if running on a device.

---

## Notes

- Add authentication (JWT) and booking/payment flows as needed.
- Extend models/serializers for more features.
- For production: set proper secrets and environment variables, don't use DEBUG=True.
EOF

# Git / push
git init
git add .
git commit -m "Add SkillShare MVP scaffold (backend + frontend)"
git branch -M "${BRANCH}"
git remote add origin "${REPO_URL}"
echo "Pushing to ${REPO_URL} (branch ${BRANCH})..."
git push -u origin "${BRANCH}"
echo "Done. Your scaffold has been pushed to ${REPO_URL} on branch ${BRANCH}."