import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const API_BASE = 'http://10.0.2.2:8000/api'; // use 10.0.2.2 for Android emulator

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SkillShare MVP',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List services = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    fetchServices();
  }

  Future fetchServices() async {
    try {
      final res = await http.get(Uri.parse('$API_BASE/services/'));
      if (res.statusCode == 200) {
        setState(() {
          services = json.decode(res.body);
          loading = false;
        });
      } else {
        setState(() => loading = false);
      }
    } catch (e) {
      setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('SkillShare')),
      body: loading
          ? Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: services.length,
              itemBuilder: (ctx, i) {
                final s = services[i];
                return ListTile(
                  title: Text(s['title'] ?? 'No title'),
                  subtitle: Text('${(s['price_cents'] ?? 0)/100} TND'),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => ServiceDetail(service: s)),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {},
        child: Icon(Icons.add),
        tooltip: 'Add service (provider)',
      ),
    );
  }
}

class ServiceDetail extends StatelessWidget {
  final Map service;
  ServiceDetail({required this.service});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(service['title'] ?? 'Service')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(service['description'] ?? ''),
            SizedBox(height: 20),
            Text('Price: ${(service['price_cents'] ?? 0)/100} TND'),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Booking not implemented yet')));
              },
              child: Text('Book Now'),
            )
          ],
        ),
      ),
    );
  }
}